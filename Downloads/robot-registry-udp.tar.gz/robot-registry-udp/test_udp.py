"""Offline protocol/database tests: python3 -m unittest -v test_udp.py"""
import json
import sqlite3
import unittest
import udp_receiver as receiver


def packet(seq=1, session='a'*32, ip='10.2.3.4', **extra):
    data = dict(version=1, boot_id=session, seq=seq, robot_id='G200-4',
                device_id='device-1', role='一号机器人-X86', management_ip=ip,
                ssh_user='grg', ssh_port=22)
    data.update(extra)
    return json.dumps(data, ensure_ascii=False).encode()


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        receiver.initialize(self.db)

    def tearDown(self):
        self.db.close()

    def test_store_compatible_record_and_ignore_password(self):
        receiver.accept(self.db, packet(ssh_password='do-not-store'), '10.2.3.4', now=100)
        row = self.db.execute('SELECT payload,source_ip,last_seen FROM devices').fetchone()
        self.assertEqual(json.loads(row[0])['role'], '一号机器人-X86')
        self.assertNotIn('do-not-store', row[0])
        self.assertEqual(row[1:], ('10.2.3.4', 100))

    def test_duplicate_and_out_of_order_do_not_refresh_last_seen(self):
        receiver.accept(self.db, packet(2), '10.2.3.4', now=100)
        self.assertFalse(receiver.accept(self.db, packet(1), '10.2.3.9', now=200))
        self.assertFalse(receiver.accept(self.db, packet(2), '10.2.3.9', now=200))
        self.assertEqual(self.db.execute('SELECT last_seen FROM devices').fetchone()[0], 100)

    def test_old_session_rejected_after_reboot(self):
        receiver.accept(self.db, packet(100), '10.2.3.4')
        receiver.accept(self.db, packet(1, 'b'*32), '10.8.9.10')
        self.assertFalse(receiver.accept(self.db, packet(101), '10.2.3.4'))

    def test_address_change_updates_one_record(self):
        receiver.accept(self.db, packet(1), '10.2.3.4')
        receiver.accept(self.db, packet(2, ip='10.8.9.10'), '10.8.9.10')
        rows = self.db.execute('SELECT payload FROM devices').fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(json.loads(rows[0][0])['management_ip'], '10.8.9.10')

    def test_reject_bad_packets(self):
        for data in (b'{', b'[]', b'x'*1201, packet(robot_id='G200-#4'),
                     packet(seq=-1), packet(ip='127.0.0.1')):
            with self.subTest(data=data[:40]), self.assertRaises((ValueError, TypeError)):
                receiver.accept(self.db, data, '10.2.3.4')
        self.assertEqual(self.db.execute('SELECT count(*) FROM devices').fetchone()[0], 0)

    def test_session_state_survives_receiver_reinitialization(self):
        receiver.accept(self.db, packet(5), '10.2.3.4')
        receiver.initialize(self.db)
        self.assertFalse(receiver.accept(self.db, packet(4), '10.2.3.4'))


if __name__ == '__main__':
    unittest.main()
