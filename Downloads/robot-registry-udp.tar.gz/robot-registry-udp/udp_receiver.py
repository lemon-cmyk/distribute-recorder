"""UDP heartbeat receiver. Standard library only; shares registry SQLite schema."""
import ipaddress
import json
import logging
import os
import re
import signal
import socket
import sqlite3
import threading
import time
from pathlib import Path

LOG = logging.getLogger('robot-registry-udp')
STOP = threading.Event()
MAX_PACKET = 1200


def text(obj, key, maximum, pattern=None, default=None):
    value = obj.get(key, default)
    if (not isinstance(value, str) or not 1 <= len(value) <= maximum
            or any(ord(c) < 32 for c in value)
            or (pattern and not re.fullmatch(pattern, value))):
        raise ValueError('Invalid ' + key)
    return value


def ipv4(value):
    addr = ipaddress.IPv4Address(value)
    if addr.is_loopback or addr.is_unspecified or addr.is_link_local or addr.is_multicast:
        raise ValueError('Invalid management IPv4')
    return str(addr)


def decode_packet(data):
    if not 1 <= len(data) <= MAX_PACKET:
        raise ValueError('Invalid packet size')
    obj = json.loads(data.decode('utf-8'))
    if not isinstance(obj, dict) or type(obj.get('version')) is not int or obj['version'] != 1:
        raise ValueError('Invalid protocol version')
    session = text(obj, 'boot_id', 32, r'[a-f0-9]{32}')
    seq = obj.get('seq')
    if type(seq) is not int or not 1 <= seq <= 2**63 - 1:
        raise ValueError('Invalid sequence')
    report = {key: text(obj, key, 64, r'[A-Za-z0-9_.-]+')
              for key in ('robot_id', 'device_id')}
    report['role'] = text(obj, 'role', 32)
    for key, maximum in (('hostname', 128), ('interface', 32)):
        value = obj.get(key, '')
        if not isinstance(value, str) or len(value) > maximum or any(ord(c) < 32 for c in value):
            raise ValueError('Invalid ' + key)
        report[key] = value
    report['management_ip'] = ipv4(obj.get('management_ip'))
    ips = obj.get('ips', [])
    if not isinstance(ips, list) or len(ips) > 32:
        raise ValueError('Invalid IP list')
    report['ips'] = list(dict.fromkeys(ipv4(value) for value in ips))
    report['ssh_user'] = text(obj, 'ssh_user', 32, r'[a-z_][a-z0-9_-]*\$?', 'ubuntu')
    port = obj.get('ssh_port', 22)
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('Invalid SSH port')
    report['ssh_port'] = port
    # Unknown fields (including passwords) are never persisted.
    return report, session, seq


def initialize(db):
    db.execute('PRAGMA journal_mode=WAL')
    db.executescript('''
      CREATE TABLE IF NOT EXISTS devices (
        device_id TEXT PRIMARY KEY, payload TEXT NOT NULL,
        source_ip TEXT NOT NULL, last_seen REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS udp_sessions (
        device_id TEXT NOT NULL, session TEXT NOT NULL,
        max_seq INTEGER NOT NULL, active INTEGER NOT NULL,
        PRIMARY KEY(device_id, session));
    ''')
    db.commit()


def accept(db, data, source_ip, now=None):
    report, session, seq = decode_packet(data)
    device = report['device_id']
    with db:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT max_seq,active FROM udp_sessions WHERE device_id=? AND session=?',
                         (device, session)).fetchone()
        if row and (not row[1] or seq <= row[0]):
            return False
        if row is None:
            db.execute('UPDATE udp_sessions SET active=0 WHERE device_id=?', (device,))
            db.execute('INSERT INTO udp_sessions VALUES(?,?,?,1)', (device, session, seq))
        else:
            db.execute('UPDATE udp_sessions SET max_seq=? WHERE device_id=? AND session=?',
                       (seq, device, session))
        db.execute('''INSERT INTO devices VALUES(?,?,?,?) ON CONFLICT(device_id)
            DO UPDATE SET payload=excluded.payload,source_ip=excluded.source_ip,last_seen=excluded.last_seen''',
            (device, json.dumps(report, ensure_ascii=False), source_ip,
             time.time() if now is None else now))
    return True


def allowed(source, networks):
    return not networks or any(ipaddress.ip_address(source) in net for net in networks)


def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    path = Path(os.environ.get('DB_PATH', '/var/lib/robot-registry/devices.db'))
    bind = os.environ.get('UDP_BIND_IP', '10.1.47.61')
    port = int(os.environ.get('UDP_PORT', '18080'))
    networks = [ipaddress.ip_network(value.strip()) for value in
                os.environ.get('UDP_ALLOWED_CIDRS', '').split(',') if value.strip()]
    path.parent.mkdir(parents=True, exist_ok=True)
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    signal.signal(signal.SIGINT, lambda *_: STOP.set())
    with sqlite3.connect(path, timeout=10) as db, socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as udp:
        initialize(db)
        udp.bind((bind, port))
        udp.settimeout(1)
        LOG.info('Listening %s:%s/UDP', bind, port)
        received = stale = rejected = 0
        last_log = time.monotonic()
        while not STOP.is_set():
            try:
                data, peer = udp.recvfrom(MAX_PACKET + 1)
                if not allowed(peer[0], networks):
                    rejected += 1
                    continue
                if accept(db, data, peer[0]):
                    received += 1
                else:
                    stale += 1
            except socket.timeout:
                pass
            except (ValueError, TypeError, KeyError, UnicodeError, RecursionError):
                rejected += 1
            # SQLite/I/O failures exit so systemd can restart; never log packet contents.
            if time.monotonic() - last_log >= 30:
                LOG.info('Last interval: accepted=%d stale=%d rejected=%d', received, stale, rejected)
                received = stale = rejected = 0
                last_log = time.monotonic()


if __name__ == '__main__':
    main()
