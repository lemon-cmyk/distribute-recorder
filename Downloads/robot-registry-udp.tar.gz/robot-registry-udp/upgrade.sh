#!/usr/bin/env bash
set -euo pipefail
if [[ "$EUID" -ne 0 ]]; then echo '请执行 sudo bash upgrade.sh'; exit 1; fi
if [[ ! -x /opt/robot-registry/.venv/bin/uvicorn || ! -f /etc/robot-registry.env ]]; then
  echo '此包用于升级聊天中已部署的服务器；未发现现有环境。'; exit 1
fi
source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -e /opt/robot-registry/server.py.pre-udp ]]; then
  cp /opt/robot-registry/server.py /opt/robot-registry/server.py.pre-udp
  cp /opt/robot-registry/index.html /opt/robot-registry/index.html.pre-udp
fi
install -m 644 "$source_dir/server.py" "$source_dir/index.html" "$source_dir/udp_receiver.py" /opt/robot-registry/
install -m 644 "$source_dir/robot-registry-udp.service" /etc/systemd/system/robot-registry-udp.service
systemctl daemon-reload
systemctl restart robot-registry
systemctl enable robot-registry-udp
systemctl restart robot-registry-udp
systemctl status robot-registry robot-registry-udp --no-pager
echo 'UDP 接收端口默认 10.1.47.61:18080；请按实际来源网段配置防火墙。'
