"""Robot registry: Python 3.10+, FastAPI, SQLite. One Uvicorn worker."""
import json
import os
import secrets
import sqlite3
import time
from contextlib import asynccontextmanager, contextmanager
from ipaddress import ip_address
from pathlib import Path
from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials

DB_PATH = Path(os.environ.get("DB_PATH", "/var/lib/robot-registry/devices.db"))
WEB_USERNAME = os.environ.get("WEB_USERNAME", "admin")
WEB_PASSWORD = os.environ["WEB_PASSWORD"]
OFFLINE_SECONDS = int(os.environ.get("OFFLINE_SECONDS", "45"))
if len(WEB_PASSWORD) < 16:
    raise RuntimeError("WEB_PASSWORD needs >=16 characters")
if OFFLINE_SECONDS < 10:
    raise RuntimeError("OFFLINE_SECONDS must be >=10")


@contextmanager
def database():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        with conn:
            yield conn
    finally:
        conn.close()


@asynccontextmanager
async def lifespan(app):
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with database() as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("""CREATE TABLE IF NOT EXISTS devices (
            device_id TEXT PRIMARY KEY,
            payload TEXT NOT NULL,
            source_ip TEXT NOT NULL,
            last_seen REAL NOT NULL
        )""")
    yield


app = FastAPI(title="Robot Registry", lifespan=lifespan,
              docs_url=None, redoc_url=None, openapi_url=None)
basic = HTTPBasic(auto_error=False)


def same(a, b):
    return secrets.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def require_web(credentials: Annotated[HTTPBasicCredentials | None, Depends(basic)]):
    if credentials is None:
        raise HTTPException(401, "Login required", headers={"WWW-Authenticate": "Basic"})
    valid_user = same(credentials.username, WEB_USERNAME)
    valid_password = same(credentials.password, WEB_PASSWORD)
    if not (valid_user and valid_password):
        raise HTTPException(401, "Invalid login", headers={"WWW-Authenticate": "Basic"})


@app.middleware("http")
async def no_cache(request: Request, call_next):
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    return response


@app.get("/healthz")
def health():
    with database() as db:
        db.execute("SELECT 1").fetchone()
    return {"status": "ok"}


@app.get("/", dependencies=[Depends(require_web)])
def home():
    return FileResponse(Path(__file__).with_name("index.html"))


@app.get("/api/devices", dependencies=[Depends(require_web)])
def devices():
    now = time.time()
    with database() as db:
        rows = db.execute("SELECT * FROM devices ORDER BY device_id").fetchall()
    result = []
    for row in rows:
        item = json.loads(row["payload"])
        age = max(0, now - row["last_seen"])
        item.update(source_ip=row["source_ip"], last_seen=row["last_seen"],
                    age_seconds=round(age), online=age < OFFLINE_SECONDS)
        result.append(item)
    result.sort(key=lambda item: (item["robot_id"], item["device_id"]))
    return JSONResponse({"devices": result, "offline_seconds": OFFLINE_SECONDS})
