# 服务端 UDP 升级包

适用于本聊天已部署的 /opt/robot-registry、/etc/robot-registry.env 和现有 SQLite 数据库。
网页保留 TCP 8080 和原账号密码；设备心跳改用固定 10.1.47.61:18080/UDP。
不需要重建虚拟环境、数据库或网页账号。UDP 接收器只用 Python 标准库。

## 升级

先上传 robot-registry-udp.tar.gz 到服务器主目录：

```bash
tar -xzf ~/robot-registry-udp.tar.gz -C ~
cd ~/robot-registry-udp
sudo bash upgrade.sh
```

ZIP 包解压进入 robot-registry-udp 文件夹后运行同一脚本。
脚本备份原网页程序为 server.py.pre-udp、index.html.pre-udp（首次保留，不反复覆盖），安装新网页程序和接收器。
现有 robot-registry.service 管理网页；新增 robot-registry-udp.service 管理 UDP 接收器，两者使用相同数据库。
新网页程序移除了 POST /api/heartbeat，因此旧 HTTP 客户端需要同步升级，否则不再更新记录。
设备查询、网页账号密码、已有设备名称和最后已知 IP 继续保留。数据表额外新增 udp_sessions，不删除原表。

## 网络放行

让 IT 放行机器人实际来源网段到 10.1.47.61:18080/UDP。TCP 8080 只用于运维浏览器，不用于新设备上报。
UFW 已启用时才按实际来源网段添加规则。例如仅当来源网段确实是 10.1.47.0/24：

```bash
sudo ufw allow from 10.1.47.0/24 to any port 18080 proto udp
```

其他区域网段分别添加；不要仅凭服务器地址推断全部机器人网段。脚本不会自动开启或修改防火墙。
客户端源端口动态分配，目的端口固定；服务器接收后不回包。

可在现有 /etc/robot-registry.env 中追加（可选，默认值无需填写）：

```ini
UDP_BIND_IP=10.1.47.61
UDP_PORT=18080
```

可选应用层来源限制，例如 UDP_ALLOWED_CIDRS=10.1.47.0/24,10.20.0.0/16；替换为实际允许网段。不配置时接收所有能到达此监听地址的来源。
修改后 sudo systemctl restart robot-registry-udp。改端口必须同步更新客户端 server_port。
UDP 无身份认证、无传输加密，网页密码仅保护网页。建议配合 IT 的来源网络规则。

## 验证

```bash
sudo systemctl status robot-registry robot-registry-udp --no-pager
sudo ss -lunp 'sport = :18080'
sudo journalctl -u robot-registry-udp -n 50 --no-pager
```

应看到监听 10.1.47.61:18080。接收器每 30 秒记录 accepted、stale、rejected 计数，不记录报文原文和密码。
设备端执行一次 --once 后，在网页 http://10.1.47.61:8080 确认该设备最后上报时间更新。客户端发送成功不等于服务器收到。
未更新时先查路由/防火墙/端口，再查接收日志。网页健康检查 /healthz 仅检查网页和数据库，不证明 UDP 接收正常。

接收器最多接收 1200 字节 JSON 并校验字段。重复、乱序或已退休会话报文不刷新在线时间。
同一设备新启动会话首次出现时，旧会话被标记退休；状态保存在数据库，接收器重启后仍可过滤旧包。
尚未见过的延迟会话无法可靠判断是否过期；无认证模式不防伪造。不会将源 IP 当作设备身份，NAT 来源地址和上报管理 IP 分开保存。
设备标识重复时会互相干扰，需要保证每台计算机唯一 device_id。
会话表保留历史以避免旧包覆盖，不自动清理；频繁重启、长期运行时可另行制定保留策略。

## 回退网页程序

如需恢复旧 HTTP 上报（设备也必须切回旧客户端）：

```bash
sudo systemctl disable --now robot-registry-udp
sudo cp /opt/robot-registry/server.py.pre-udp /opt/robot-registry/server.py
sudo cp /opt/robot-registry/index.html.pre-udp /opt/robot-registry/index.html
sudo systemctl restart robot-registry
```

原 HTTP 客户端包与 UDP 包并列保存，可重新安装旧包；旧客户端可能需要重新填写原 HTTP 配置。
离线协议和数据库测试：python3 -m unittest -v test_udp.py。
