string name
string value
